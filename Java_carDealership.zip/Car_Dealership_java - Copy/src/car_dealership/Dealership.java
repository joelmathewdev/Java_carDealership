package car_dealership;

public class Dealership {
	
	

	public static void main(String[] args) {
	
		Customer cust1 = new Customer ();
		cust1.setName("Tom Sawyer");
		cust1.setAddress("221B Bakers St");
		cust1.setCashOnHand(12345.67);
		
		Customer cust2 = new Customer();
		cust2.setName("Jerry Maguire");
		cust2.setAddress("221A Bakers Blvd");
		cust2.setCashOnHand(36000);
		
		Customer cust3 = new Customer();
		cust3.setName("Paul Thankachen");
		cust3.setAddress("178 Vallalar St");
		cust3.setCashOnHand(40000);
		
		Vehicle car1 = new Vehicle();
		car1.setYear(2022);
		car1.setMake("Toyota");
		car1.setModel("Camry SE");
		car1.setPrice(35000);
		
		Employee emp1 = new Employee();
		emp1.setEmpName("Huck Finn");
				
		cust1.purchaseCar(cust1, car1, emp1, true);	
		cust2.purchaseCar(cust2, car1, emp1, true);
		cust3.purchaseCar(cust3, car1, emp1, true);
	
	}
	}
	
	
