package car_dealership;



public class Customer {
	
	private String name;
	private String address;
	private double cashOnHand;
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public double getCashOnHand() {
		return cashOnHand;
	}


	public void setCashOnHand(double cashOnHand) {
		this.cashOnHand = cashOnHand;
	}


	public void purchaseCar (Customer cust, Vehicle car, Employee emp, boolean finance) {
		System.out.println("Customer "+cust.getName()+" is being helped by Sales Associate "+emp.getEmpName()+" with this purchase.");
		emp.handleCust(this, finance, car); //this refers to corresponding variable listed earlier
	}

}
