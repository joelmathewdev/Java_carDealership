package car_dealership;

public class Employee {
	private String empName;

	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void handleCust (Customer cust, boolean finance, Vehicle car) {
		if (finance == true) {
			double loanAmount = car.getPrice() - cust.getCashOnHand();
			runCredit(cust, loanAmount, car);
		} else if (car.getPrice() <= cust.getCashOnHand()) {
			//Customer pays in cash
			processBuy (cust, car);
		} else {
			System.out.println("Customer "+cust.getName()+" is not approved to purchase the "
					+car.getYear()+" "+car.getMake()+" "+car.getModel()+
					". Please inform "+cust.getName()+" to return when theu are in a stronger financial position.");
		}
		
	}
	public void runCredit (Customer cust, double loanAmount, Vehicle car) {
		System.out.println("Ran credot history for Customer: " + cust.getName());
		System.out.println("Customer " + cust.getName() + " has been approved to purchase this " +car.getYear()+" " + car.getMake()+" "+car.getModel()+".");
		System.out.println("Congrats, "+cust.getName()+ "!");
	}
	public void processBuy (Customer cust, Vehicle car) {
		System.out.println(cust.getName()+" has purchase the "+car.getYear()+" "+car.getMake()+" "+car.getModel()+" "+ "paid "+car.getPrice()+" in full with cash.");
	}
	
	}
	

